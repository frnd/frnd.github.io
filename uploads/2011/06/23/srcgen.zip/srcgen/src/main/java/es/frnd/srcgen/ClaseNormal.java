package es.frnd.srcgen;

import es.frnd.srcgen.Version;

public class ClaseNormal {

  /**
   * @param args
   */
  public static void main(String[] args) {
    System.out.println("Sources generation Example:");
    System.out.println("Project name : " + Version.PROJECT_NAME);
    System.out.println("Version : " + Version.VERSION_NUMBER);
  }

}
