package es.frnd.srcgen;

public class Version {
  public static String PROJECT_NAME = "${project.name}";
  public static String VERSION_NUMBER = "${project.version}";
}
