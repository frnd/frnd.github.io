#set ( $symbol_pound = '#' )
#set ( $symbol_dollar = '$' )
#set ( $symbol_escape = '\' )

package ${package};

/**
 * Hello world!
 *
 */
public class ${customProperty}App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
